package com.app.myapplication.Models

import java.time.chrono.ChronoLocalDateTime

class InternalItemsModel (var itemContent : String = "",
                          var userId : String = "",
                          var data : String = "",
                          var internalItemId : String = "")

