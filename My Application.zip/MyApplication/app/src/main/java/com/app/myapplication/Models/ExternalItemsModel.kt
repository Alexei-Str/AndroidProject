package com.app.myapplication.Models

class ExternalItemsModel (var userId : String = "",
                          var internalItemId : String = "",
                          var itemPic: Int = 0,
                          var title : String = "")

